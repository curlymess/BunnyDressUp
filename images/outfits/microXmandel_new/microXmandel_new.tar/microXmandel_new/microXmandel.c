/************************************************************************
 * File: microXmandel.c  Program: microXmandel, same as miniXmandel
 * but with 128 x 128 pixels and 4 x 4 tiles
 *
 * Andrea Di Blas, april 24, 2002, rev. 2013, rev. 2014
 * Mandelbrot set microscope for Kestrel
 *
 * NOTE: the X resource binding file is in ~/MicroXmandel.x
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#define NROWS      64   /*  number of pixel rows */
#define NPES       64   /*  number of pixel columns = # of PEs */
#define NPESMONE   63   /* # of PEs - 1 */

int     MAXITER;        /* max number of main loop iterations */

double  fXo, fYo;       /* upper-left corner */
double  fXn, fYn;       /* lower-right corner */
double  fdX, fdY;       /* horizontal and vertical increment */
long    Xo, Yo;         /* integer upper-left corner */
long    Xn, Yn;         /* integer lower-right corner */
long    dX, dY;         /* integer horizontal and vertical incr. */
long	  dX8, dY8;				/* integer tile horizontal and vertical incr. */
long	  dX64;					  /* integer tile horizontal incr. for mandel6.kasm */

/*******************************************************************/
/* generates Mandelbrot set view for the region in (Xo, Yo)-(Xn, Yn)
 * and also writes cMandOut file */
void
generate_view()
{
  int	    i;			  /* rows index */
  int 	  j; 			  /* columns index */
  FILE	 *fp;		    /* output file */
  double  a;			  /* Re{z} */
  double	b;			  /* Im{z} */
  double	x;			  /* Re{c} */
  double	y;			  /* Im{c} */
  int	    counter;	/* iteration counter */
  double	aa, bb;		/* buffer */

  if((fp = fopen("cMandOut", "w")) == NULL)
  {	fprintf(stderr, "\n*** error opening file cMandOut ***\n");
    exit(1);
  }

  /* writes MAXITER to cmandout file, lsb first */
  fprintf(fp, "%i\n%i\n", MAXITER & 255, (MAXITER >> 8) & 255);

  printf("\nS                                                  E\n");

  y = fYo;
  for(i = 0; i < NROWS; ++i)
  {	  x = fXo;
      for(j = 0; j < NPES; ++j)
	  {	  counter = 0;
	      a = x;
		  b = y;
		  aa = a * a;
		  bb = b * b;
		  while((aa + bb) < 4.0 && counter < MAXITER)
		  {	  ++counter;
		      b = 2.0 * a * b + y;
			  a = aa - bb + x;
			  aa = a * a;
			  bb = b * b;
		  }
		  fprintf(fp, "%i\n%i\n", counter & 255, (counter >> 8) & 255);
		 x += fdX;
	  }
	  y -= fdY;
	  if(i % 10 == 0)  printf(".");
	  fflush(stdout);
  }

	printf("\n\nOutput written also to file: cMandOut\n");

  fclose(fp);
}
/*------------------------------------------------------------------*/
/********************************************************************/
/********************************************************************/
/********************************************************************/
