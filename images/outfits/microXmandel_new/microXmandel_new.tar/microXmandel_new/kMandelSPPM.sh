#!/bin/csh -f
kestrel kMandelSPPMMicro.ko kMandIn kMandOutSPPM 64
