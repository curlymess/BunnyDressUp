#!/bin/csh -f
kestrel kMandelSyncMicro.ko kMandIn kMandOutSync 64
