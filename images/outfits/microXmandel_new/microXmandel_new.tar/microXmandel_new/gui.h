/************************************************************************
 * File: gui.h Program: microXmandel
 * Contents: Internal data structures definition
 *           for  graphical user interface
 * Andrea Di Blas, february 2013, feb. 2014
 ************************************************************************/

#ifndef GUI_H

#include <X11/Intrinsic.h>
#include <time.h>

extern Widget top_shell;
extern Widget top_form;
extern Widget draw_box;
extern Widget button_box;

void      start_kestrel_cb();
void      start_kestrel_tiles_cb();
void      start_cpu_cb();
void      load_cb();
void      loadp_cb();
void      clear_cb();
void      par_cb();
void      grid_cb();
void      quit_cb();

extern Display  *display;
extern GC	      draw_box_gc;					    /* private GC for draw_box */
extern XColor	  rosso, red;					      /* color asked, color obtained */
extern XColor	  verde, green;				      /* color asked, color obtained */
extern XColor	  blu, blue;					      /* color asked, color obtained */
extern XColor	  giallo, yellow;				    /* color asked, color obtained */
extern XColor	  azzurro, cyan;				    /* color asked, color obtained */
extern XColor	  grigiochiaro, lightgrey;	/* color asked, color obtained */
extern XColor	  rosa, pink;					      /* color asked, color obtained */
extern XColor	  arancio, orange;			    /* color asked, color obtained */
extern XColor	  grigioscuro, darkgrey;		/* color asked, color obtained */

#include	<stdio.h>
#include	<stdlib.h>
#include	<math.h>

extern int		MAXITER;			/* max number of main loop iterations */

extern double 	fXo, fYo;		/* upper-left corner */
extern double 	fXn, fYn;		/* lower-right corner */
extern double 	fdX, fdY;	  /* horizontal and vertical increment */
extern long 	  Xo, Yo;			/* integer upper-left corner */
extern long 	  Xn, Yn;		  /* integer lower-right corner */
extern long 	  dX, dY;		  /* integer horizontal and vertical pixel incr. */
extern long 	  dXt, dYt;	  /* integer tile horizontal and vertical incr. */

int
main(int argc, char **argv);

void
display_file(FILE	*fp);	/* load and display a file, computing the band */

int
generate_view(void);		/* generate view using cpu */

long
f2long8(double d);

void
inputParams(void);

void
cdisplay_file(FILE *fp);

void
pdisplay_file(FILE *fp);

void
pdisplay_file2(FILE *fp);

#define GUI_H
#endif /* GUI_H */
