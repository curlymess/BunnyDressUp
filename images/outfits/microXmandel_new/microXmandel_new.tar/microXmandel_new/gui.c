/************************************************************************
 * File: gui.c	Program: microXmandel: same as miniXmandel but 64 x 64
 * with 4 x 4 tiles
 *
 * Contents: Callbacks for main gui
 * Andrea Di Blas, april 24, 2002
 * rev. 2005, rev. 2013, rev. 2014
 ************************************************************************/

#include  <X11/Intrinsic.h>
#include  <X11/Shell.h>
#include  <X11/Xaw/Dialog.h>
#include  <X11/Xaw/List.h>
#include  <curses.h>

int NROWS     = 64;     /*  number of pixel rows */
int NPES      = 64;     /*  number of pixel columns = # of PEs */
int NPESMONE  = 63;     /* # of PEs - 1 */
int TOTTILE   = 256;    /* total number of tiles */
int PROWS     = 4;      /* rows in each tile */
int PCOLS     = 4;      /* columns in each tile */
int TileSize  = 4;      /* 8, 4, 2 */

long 	  dXt, dYt;	  /* integer tile horizontal and vertical incr. */

#include "gui.h"

/*----------------------------------------------------------------------*/
void
start_cpu_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  FILE *fp;
  clock_t ctstart, ctend;

  inputParams();

  printf("\nStart: ");
  system("date");
  ctstart = clock();

  generate_view();

  ctend = clock();
  printf("\n  End: ");
  system("date");
  printf("CPU time = %.3f seconds\n",
      (float) (ctend - ctstart) / (float) CLOCKS_PER_SEC);

  if ((fp = fopen("cMandOut", "r")) == NULL )
  {
    fprintf(stderr, "\n*** file cMandOut not found ***");
    exit(1);
  }

  cdisplay_file(fp);

  fclose(fp);
}
/*----------------------------------------------------------------------*/
void
start_kestrel_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  FILE *fp;
  char s[32];
  int c;

  inputParams();

  if ((fp = fopen("kMandIn", "w")) == NULL )
  {
    fprintf(stderr, "\n*** error opening file kMandIn ***\n");
    exit(1);
  }

  /* writes MAXITER to kMandIn file, lsb first */
  fprintf(fp, "%d\n%d\n", MAXITER & 255, (MAXITER >> 8) & 255);
  /* writes Xo to k7in file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", Xo & 255L, (Xo >> 8) & 255L,
      (Xo >> 16) & 255L, (Xo >> 24) & 255L);
  /* writes Yo to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", Yo & 255L, (Yo >> 8) & 255L,
      (Yo >> 16) & 255L, (Yo >> 24) & 255L);
  /* writes dX to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", dX & 255L, (dX >> 8) & 255L,
      (dX >> 16) & 255L, (dX >> 24) & 255L);
  /* writes dY to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", dY & 255L, (dY >> 8) & 255L,
      (dY >> 16) & 255L, (dY >> 24) & 255L);
  fclose(fp);

  /* run synchronous Kestrel implementation */
  system("./kMandelSync.sh");

  if ((fp = fopen("kMandOutSync", "r")) == NULL )
  {
    fprintf(stderr, "\n*** file kMandOutSync not found ***");
    exit(1);
  }
  cdisplay_file(fp);
  fclose(fp);
}
/*----------------------------------------------------------------------*/
void
start_kestrel_tiles_cb(Widget w, XEvent *event, String *params,
    Cardinal *num_params)
{
  FILE *fp;
  char s[32];
  int c;

  inputParams();

  if ((fp = fopen("kMandIn", "w")) == NULL )
  {
    fprintf(stderr, "\n*** error opening file kMandIn ***\n");
    exit(1);
  }

  /* writes MAXITER to kMandIn file, lsb first */
  fprintf(fp, "%d\n%d\n", MAXITER & 255, (MAXITER >> 8) & 255);
  /* writes Xo to k7in file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", Xo & 255L, (Xo >> 8) & 255L,
      (Xo >> 16) & 255L, (Xo >> 24) & 255L);
  /* writes Yo to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", Yo & 255L, (Yo >> 8) & 255L,
      (Yo >> 16) & 255L, (Yo >> 24) & 255L);
  /* writes dX to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", dX & 255L, (dX >> 8) & 255L,
      (dX >> 16) & 255L, (dX >> 24) & 255L);
  /* writes dY to kMandIn file, byte per byte, lsb first */
  fprintf(fp, "%ld\n%ld\n%ld\n%ld\n", dY & 255L, (dY >> 8) & 255L,
      (dY >> 16) & 255L, (dY >> 24) & 255L);

  fclose(fp);

  /* start SPPM Kestrel implementation */
  system("./kMandelSPPM.sh");

  if ((fp = fopen("kMandOutSPPM", "r")) == NULL )
  {
    fprintf(stderr, "\n*** file kMandOutSPPM not found ***");
    exit(1);
  }

  pdisplay_file(fp);

  fclose(fp);
}
/*----------------------------------------------------------------------*/
void
clear_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  int rr, cc;

  XSetForeground(display, draw_box_gc, grigioscuro.pixel);
  /* 	XSetForeground(display, draw_box_gc, WhitePixel(display,0)); */

  for (rr = 0; rr < 64; ++rr)
    for (cc = 0; cc < 64; ++cc)
      XDrawPoint(display, XtWindow(draw_box), draw_box_gc, cc, rr);

  /*  XClearWindow(display, XtWindow(draw_box)); */
}
/*----------------------------------------------------------------------*/
void
load_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  FILE *fp;
  char file[128]; /* file name */

  printf("\nLoad CPU or synchronous file: ");
  scanf("%s", file);

  if ((fp = fopen(file, "r")) == NULL )
    fprintf(stderr, "\n*** file %s not found ***\n", file);
  else
  {
    cdisplay_file(fp);
    fclose(fp);
  }
}
/*----------------------------------------------------------------------*/
void
loadp_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  FILE *fp;
  char file[128]; /* file name */

  printf("\nLoad tile (SPPM) file: ");
  scanf("%s", file);

  if ((fp = fopen(file, "r")) == NULL )
    fprintf(stderr, "\n*** file %s not found ***\n", file);
  else
  {
    pdisplay_file2(fp);
    fclose(fp);
  }
}
/*----------------------------------------------------------------------*/
/* loads and displays a CPU-generated or Kestrel synchronous file
 * "band" is a naive strategy to get a pretty coloring
 */
void
cdisplay_file(FILE *fp)
{
  short int r, c;         /* row, column */
  int       pl, ph;       /* low and high byte of pixel counter */
  int       deltap;       /* band distance */
  int       b;            /* char buffer */
  int       i, j;
  long      DIST[1000];   /* pixel distribution */
  int       BAND[15];     /* color bands thresholds */
  long      setpoints;    /* # of points in the set, i.e. = MAXITER */
  long      share;        /* approximate # of points per band, set excl. */
  long      bunch;
  int       boh;

  /* find the distribution and the minimum */
  for (i = 0; i < 1000; ++i)
    DIST[i] = 0;
  setpoints = 0;
  for (i = 0; i < 15; ++i)
    BAND[i] = 0;

  /* read MAXITER from file */
  fscanf(fp, "%d", &MAXITER);
  fscanf(fp, "%d", &b);
  MAXITER += b << 8;

  if (MAXITER >= 1000)
    deltap = MAXITER / 1000;
  else
    deltap = 1;

  printf("\nMAXITER = %d, deltap = %d", MAXITER, deltap);

  for (r = 0; r < NROWS; ++r)
  {
    for (c = 0; c < NPES; ++c)
    {
      fscanf(fp, " %d %d", &pl, &ph);
      ph <<= 8;
      ph += pl;
      if (ph >= MAXITER)
        ++setpoints;
      else
        ++(DIST[ph / deltap]);
    }
  }

  printf("\n\nsetpoints = %li", setpoints);

  /* assign the band values */
  share = (NROWS * NPES - setpoints) / 16;
  printf("\n\nshare = %li\n", share);
  j = 14;
  bunch = 0;
  for (i = 999; i >= 0 && j >= 0; --i)
  {
    bunch += DIST[i];
    if (bunch >= share)
    {
      BAND[j--] = i * deltap;
      printf("\nin BAND[%2i] = %6i there are %6li points", j + 1, BAND[j + 1],
          bunch);
      bunch = 0;
    }
  }
  printf("\n");

  /* plot the points */
  rewind(fp);
  /* fseek(fp, 0L, SEEK_SET); */

  /* read MAXITER from file again */
  fscanf(fp, "%d", &MAXITER);
  fscanf(fp, "%d", &b);
  MAXITER += b << 8;

  for (r = 0; r < NROWS; ++r)
  {
    for (c = 0; c < NPES; ++c)
    {
      fscanf(fp, " %d %d", &pl, &ph);
      ph <<= 8;
      ph += pl;
      if (ph <= BAND[0])
        XSetForeground(display, draw_box_gc, BlackPixel(display, 0) );
        else
        if (ph <= BAND[1])
        XSetForeground(display, draw_box_gc, azzurro.pixel);
        else
        if (ph <= BAND[2])
        XSetForeground(display, draw_box_gc, grigiochiaro.pixel);
        else
        if (ph <= BAND[3])
        XSetForeground(display, draw_box_gc, giallo.pixel);
        else
        if (ph <= BAND[4])
        XSetForeground(display, draw_box_gc, rosso.pixel);
        else
        if (ph <= BAND[5])
        XSetForeground(display, draw_box_gc, verde.pixel);
        else
        if (ph <= BAND[6])
        XSetForeground(display, draw_box_gc, blu.pixel);
        else
        if (ph <= BAND[7])
        XSetForeground(display, draw_box_gc,
            WhitePixel(display, 0));
        else
        if (ph <= BAND[8])
        XSetForeground(display, draw_box_gc,
            grigiochiaro.pixel);
        else
        if (ph <= BAND[9])
        XSetForeground(display, draw_box_gc, azzurro.pixel);
        else
        if (ph <= BAND[10])
        XSetForeground(display, draw_box_gc, giallo.pixel);
        else
        if (ph <= BAND[11])
        XSetForeground(display, draw_box_gc, verde.pixel);
        else
        if (ph <= BAND[12])
        XSetForeground(display, draw_box_gc,
            rosso.pixel);
        else
        if (ph <= BAND[13])
        XSetForeground(display, draw_box_gc,
            grigiochiaro.pixel);
        else
        if (ph <= BAND[14])
        XSetForeground(display, draw_box_gc,
            blu.pixel);
        else
        if (ph < MAXITER)
        XSetForeground(display, draw_box_gc,
            WhitePixel(display, 0));
        else
        XSetForeground(display, draw_box_gc,
            BlackPixel(display, 0));

      XDrawPoint(display, XtWindow(draw_box), draw_box_gc, c, r);
    }
  }
  return;
}
/*------------------------------------------------------------------*/
/* load and display a tile file */
void
pdisplay_file(FILE *fp)
{
  short int   r, c;         /* row, column */
  int         pl, ph;       /* low and high byte of pixel counter */
  int         deltap;       /* band distance */
  int         b;            /* char buffer */
  int         i, j;
  long        DIST[1000];   /* pixel distribution */
  long       *DISTX;        /* pixel distribution with calloc() */
  int         BAND[15];     /* color bands thresholds */
  long        setpoints;    /* # of points in the set, i.e. = MAXITER */
  long        share;        /* approx # of points per band, set excluded */
  long        bunch;
  int         boh;
  int         tilerow;      /* row of the tile */
  int         tilecol;      /* column of the tile */
  int         max;          /* max pixel value < MAXITER */
  int         bon;          /* banding parameter */
  double      nosetavg;     /* avg iterations for pixels not in the set */

  /* find the distribution and the minimum */
  for (i = 0; i < 1000; ++i)
    DIST[i] = 0;
  setpoints = 0;
  for (i = 0; i < 15; ++i)
    BAND[i] = 0;

  /* read MAXITER from file */
  fscanf(fp, "%d", &MAXITER);
  fscanf(fp, "%d", &b);
  MAXITER += b << 8;

  /* read TileSize from file */
  fscanf(fp, "%d", &TileSize);

  /* compute TOTTILE, PROWS, PCOLS */
  TOTTILE = (NROWS * NPES) / (TileSize * TileSize);
  PROWS = PCOLS = TileSize;

  printf("\nTOTTILE = %i", TOTTILE);
  printf("\nPROWS = %i, PCOLS = %i, TileSize = %i\n", PROWS, PCOLS, TileSize);

  if (MAXITER >= 1000)
    deltap = MAXITER / 1000;
  else
    deltap = 1;

  printf("\nMAXITER = %d, deltap = %d", MAXITER, deltap);

  printf("\n\nBanding parameter? ");
  scanf("%d", &bon);

  max = 0;

  if ((DISTX = (long *) calloc(MAXITER, sizeof(long int))) == NULL )
  {
    fprintf(stderr, "\n\n*** out of memory (calloc()) ***\n\n");
    return;
  }

  for (i = 0; i < TOTTILE; ++i)
  {
    fscanf(fp, " %*i %*i"); /* skip TILEN */
    for (r = 0; r < PROWS; ++r)
      for (c = 0; c < PCOLS; ++c)
      {
        fscanf(fp, " %i %i", &pl, &ph);
        ph <<= 8;
        ph += pl;
        if (ph >= MAXITER)
          ++setpoints;
        else
        {
          max = ph > max ? ph : max;
          ++(DISTX[ph]);
        }
      }
  }

  printf("\n\nsetpoints = %li", setpoints);

  share = (NROWS * NPES - setpoints) / bon;
  printf("\n\nshare = %ld\n", share);
  j = 14;
  bunch = 0;
  for (i = MAXITER - 1; i >= 0 && j >= 0; --i)
  {
    bunch += DISTX[i];
    if (bunch >= share)/*  || (bunch >= share/4 && i%(MAXITER/16) == 0)) */
    {
      BAND[j--] = i;
      printf("\nin BAND[%2d] = %6d there are %6ld points", j + 1, BAND[j + 1],
          bunch);
      bunch = 0;
    }
  }

  nosetavg = 0;
  for (i = MAXITER - 1; i >= 0; --i)
    nosetavg += (double) (DISTX[i] * i);

  nosetavg /= (double) (NROWS * NPES - setpoints + 1);

  printf("\nnosetavg = %lf\nsetpointspercentage = %lf", nosetavg,
      (double) setpoints / (double) (NROWS * NPES));
  free(DISTX);

  /*-------------------------------
   * plot the points
   */
  rewind(fp);
  /* read MAXITER from file again */
  fscanf(fp, "%d", &MAXITER);
  fscanf(fp, "%d", &b);
  MAXITER += b << 8;

  /* read TileSize from file again */
  fscanf(fp, "%d", &TileSize);
  printf("\nMAXITER = %d", MAXITER);

  for (i = 0; i < TOTTILE; ++i)
  {
    fscanf(fp, " %d %d", &tilecol, &tilerow);
    /* DEBUG */
//    printf("tile %4d: %2d, %2d", i, tilecol, tilerow);
//    getchar();

    for (r = 0; r < PROWS; ++r)
    {
      for (c = 0; c < PCOLS; ++c)
      {
        fscanf(fp, " %d %d", &pl, &ph);
        ph <<= 8;
        ph += pl;
        if (ph <= BAND[0])
          XSetForeground(display, draw_box_gc, BlackPixel(display, 0) );
          else
          if (ph <= BAND[1])
          XSetForeground(display, draw_box_gc, giallo.pixel);
          else
          if (ph <= BAND[2])
          XSetForeground(display, draw_box_gc, rosa.pixel);
          else
          if (ph <= BAND[3])
          XSetForeground(display, draw_box_gc, blu.pixel);
          else
          if (ph <= BAND[4])
          XSetForeground(display, draw_box_gc, azzurro.pixel);
          else
          if (ph <= BAND[5])
          XSetForeground(display, draw_box_gc, giallo.pixel);
          else
          if (ph <= BAND[6])
          XSetForeground(display, draw_box_gc, verde.pixel);
          else
          if (ph <= BAND[7])
          XSetForeground(display, draw_box_gc,
              grigiochiaro.pixel);
          else
          if (ph <= BAND[8])
          XSetForeground(display, draw_box_gc, arancio.pixel);
          else
          if (ph <= BAND[9])
          XSetForeground(display, draw_box_gc, rosso.pixel);
          else
          if (ph <= BAND[10])
          XSetForeground(display, draw_box_gc,
              giallo.pixel);
          else
          if (ph <= BAND[11])
          XSetForeground(display, draw_box_gc,
              grigiochiaro.pixel);
          else
          if (ph <= BAND[12])
          XSetForeground(display, draw_box_gc,
              azzurro.pixel);
          else
          if (ph <= BAND[13])
          XSetForeground(display, draw_box_gc,
              rosa.pixel);
          else
          if (ph <= BAND[14])
          XSetForeground(display, draw_box_gc,
              blu.pixel);
          else
          if (ph < MAXITER)
          XSetForeground(display, draw_box_gc,
              WhitePixel(display, 0));
          else
          XSetForeground(display, draw_box_gc,
              BlackPixel(display, 0));

        XDrawPoint(display, XtWindow(draw_box), draw_box_gc,
            tilecol * TileSize + c, tilerow * TileSize + r);
        /* fprintf(fplot, "%i  %i  %i\n", tilecol*TileSize+c, tilerow*TileSize+r, ph); */
      }
    }
  }
  return;
}
/*------------------------------------------------------------------*/
/* loads and displays a tile file, version 2 with different coloring */
void
pdisplay_file2(FILE *fp)
{
  short int     r, c;         /* row, column */
  int           pl, ph;       /* low and high byte of pixel counter */
  int           deltap;       /* band distance */
  int           b;            /* char buffer */
  int           i, j;
  long          DIST[1000];   /* pixel distribution */
  long         *DISTX;        /* pixel distribution with calloc() */
  int           BAND[15];     /* color bands thresholds */
  long          setpoints;    /* # of points in the set, i.e. = MAXITER */
  long          share;        /* approx # of points per band, set excluded */
  long          bunch;
  int           boh;
  int           tilerow;      /* row of the tile */
  int           tilecol;      /* column of the tile */
  int           max;          /* max pixel value < MAXITER */
  int           bon;          /* banding parameter */
  double        nosetavg;     /* avg iterations for pixels not in the set */
  int           shift;
  int           red, green, blue;
  unsigned long color;

  /*-------------------------------------------
   * finding the distribution and the minimum
   */

  for (i = 0; i < 1000; ++i)
    DIST[i] = 0;
  setpoints = 0;
  for (i = 0; i < 15; ++i)
    BAND[i] = 0;

  /* read MAXITER from file */
  fscanf(fp, "%i", &MAXITER);
  fscanf(fp, "%i", &b);
  MAXITER += b << 8;

  /* read PathcSize from file */
  fscanf(fp, "%i", &TileSize);

  /* compute TOTTILE, PROWS, PCOLS */
  TOTTILE = (NROWS * NPES) / (TileSize * TileSize);
  PROWS = PCOLS = TileSize;

  printf("\nTOTTILE = %i", TOTTILE);
  printf("\nPROWS = %i, PCOLS = %i, TileSize = %i\n", PROWS, PCOLS, TileSize);

  if (MAXITER >= 1000)
    deltap = MAXITER / 1000;
  else
    deltap = 1;

  printf("\nMAXITER = %i, deltap = %i", MAXITER, deltap);

  printf("\n\nBanding parameter? ");
  scanf("%d", &bon);
  printf("Red parameter? ");
  scanf("%d", &red);
  printf("Green parameter? ");
  scanf("%d", &green);
  printf("Blue parameter? ");
  scanf("%d", &blue);

  max = 0;

  if ((DISTX = (long *) calloc(MAXITER, sizeof(long int))) == NULL )
  {
    fprintf(stderr, "\n\n*** out of memory (calloc()) ***\n\n");
    return;
  }

  for (i = 0; i < TOTTILE; ++i)
  {
    fscanf(fp, " %*i %*i"); /* skip TILEN */
    for (r = 0; r < PROWS; ++r)
      for (c = 0; c < PCOLS; ++c)
      {
        fscanf(fp, " %i %i", &pl, &ph);
        ph <<= 8;
        ph += pl;
        if (ph >= MAXITER)
          ++setpoints;
        else
        {
          max = ph > max ? ph : max;
          ++(DISTX[ph]);
        }
      }
  }

  printf("\n\nsetpoints = %li", setpoints);

  share = (NROWS * NPES - setpoints) / bon;
  printf("\n\nshare = %li\n", share);
  j = 14;
  bunch = 0;
  for (i = MAXITER - 1; i >= 0 && j >= 0; --i)
  {
    bunch += DISTX[i];
    if (bunch >= share)/*  || (bunch >= share/4 && i%(MAXITER/16) == 0)) */
    {
      BAND[j--] = i;
      printf("\nin BAND[%2d] = %6d there are %6ld points", j + 1, BAND[j + 1],
          bunch);
      bunch = 0;
    }
  }

  nosetavg = 0;
  for (i = MAXITER - 1; i >= 0; --i)
    nosetavg += (double) (DISTX[i] * i);

  nosetavg /= (double) (NROWS * NPES - setpoints + 1);

  printf("\nnosetavg = %lf\nsetpointspercentage = %lf", nosetavg,
      (double) setpoints / (double) (NROWS * NPES));
  free(DISTX);

  /*----------------------------------------------
   * plot the points
   */
  rewind(fp);

  /* read MAXITER from file again */
  fscanf(fp, "%i", &MAXITER);
  fscanf(fp, "%i", &b);
  MAXITER += b << 8;

  /* read TileSize from file again */
  fscanf(fp, "%i", &TileSize);
  printf("\nMAXITER = %i", MAXITER);

  for (i = 0; i < TOTTILE; ++i)
  {
    fscanf(fp, " %i %i", &tilecol, &tilerow);
    for (r = 0; r < PROWS; ++r)
    {
      for (c = 0; c < PCOLS; ++c)
      {
        fscanf(fp, " %i %i", &pl, &ph);
        ph <<= 8;
        ph += pl;

        color = ((unsigned long) ph << blue)
            | ((unsigned long) ph << (8 + green))
            | ((unsigned long) ph << (16 + red));

        if (ph <= BAND[14])
          XSetForeground(display, draw_box_gc, color);
        else if (ph < MAXITER)
          XSetForeground(display, draw_box_gc, WhitePixel(display, 0) );
          else
          XSetForeground(display, draw_box_gc, BlackPixel(display, 0));

        XDrawPoint(display, XtWindow(draw_box), draw_box_gc,
            tilecol * TileSize + c, tilerow * TileSize + r);
        /* fprintf(fplot, "%i  %i  %i\n", tilecol*TileSize+c, tilerow*TileSize+r, ph); */
      }
    }
  }
  return;
}
/*------------------------------------------------------------------*/
/* loads and displays a file */
void
display_file(FILE *fp)
{
  short int   r, c;       /* row, column */
  int         pl, ph;     /* low and high byte of pixel counter */
  int         deltap;     /* band distance */
  int         b;          /* char buffer */
  int         i, j;
  long        DIST[1000]; /* pixel distribution */
  int         BAND[5];    /* color bands thresholds */
  long        setpoints;  /* # of points in the sert, i.e. = MAXITER */
  long        share;      /* approx # of points per band, set excluded */
  long        bunch;
  int         boh;

  /* read MAXITER from file */
  fscanf(fp, "%i", &MAXITER);
  fscanf(fp, "%i", &b);
  MAXITER += b << 8;

  for (r = 0; r < NROWS; ++r)
  {
    for (c = 0; c < NPES; ++c)
    {
      fscanf(fp, " %i %i", &pl, &ph);
      ph <<= 8;
      ph += pl;
      if (ph <= 40)
        XSetForeground(display, draw_box_gc, BlackPixel(display, 0) );
        else
        if (ph <= 50)
        XSetForeground(display, draw_box_gc, azzurro.pixel);
        else
        if (ph <= 60)
        XSetForeground(display, draw_box_gc, grigiochiaro.pixel);
        else
        if (ph <= 70)
        XSetForeground(display, draw_box_gc, giallo.pixel);
        else
        if (ph <= 80)
        XSetForeground(display, draw_box_gc, rosso.pixel);
        else
        if (ph <= 100)
        XSetForeground(display, draw_box_gc, verde.pixel);
        else
        if (ph <= 120)
        XSetForeground(display, draw_box_gc, blu.pixel);
        else
        if (ph <= 256)
        XSetForeground(display, draw_box_gc,
            WhitePixel(display, 0));
        else
        if (ph <= 500 && ph != MAXITER + 1)
        XSetForeground(display, draw_box_gc,
            grigiochiaro.pixel);
        /* 			else if(ph <= 1000 && ph != MAXITER+1)	XSetForeground(display, draw_box_gc, azzurro.pixel); */
        /* 			else if(ph <= 2000 && ph != MAXITER+1)	XSetForeground(display, draw_box_gc, giallo.pixel); */
        /* 			else if(ph <= 4000 && ph != MAXITER+1)	XSetForeground(display, draw_box_gc, verde.pixel); */
        /* 			else if(ph <= 8000 && ph != MAXITER+1)	XSetForeground(display, draw_box_gc, rosso.pixel); */
        /* 			else if(ph <= 16000 && ph != MAXITER+1)	XSetForeground(display, draw_box_gc, grigiochiaro.pixel); */
        else
        if (ph <= 32000 && ph != MAXITER + 1)
        XSetForeground(display, draw_box_gc, blu.pixel);
        else
        if (ph < MAXITER && ph != MAXITER + 1)
        XSetForeground(display, draw_box_gc,
            WhitePixel(display, 0));
        else
        XSetForeground(display, draw_box_gc,
            BlackPixel(display, 0));

      XDrawPoint(display, XtWindow(draw_box), draw_box_gc, c, r);
    }
  }
  return;
}
/*------------------------------------------------------------------*/
void
quit_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  printf("\n");
  XtDestroyWidget(top_shell);
  exit(0);
}
/*----------------------------------------------------------------------*/
void
par_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  printf("\n\nXo = %lf\nYo = %lf\nXn = %lf\nYn = %lf\n", fXo, fYo, fXn, fYn);
  printf("Delta X = %lf, Delta Y = %lf\n", fXn - fXo, fYo - fYn);
}
/*----------------------------------------------------------------------*/
void
grid_cb(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  int i;

  XSetForeground(display, draw_box_gc, grigioscuro.pixel);
  for (i = 1; i < 4; ++i)
  {
    XDrawLine(display, XtWindow(draw_box), draw_box_gc, i * (NROWS/4), 0,
        i * (NROWS/4), NROWS);
    XDrawLine(display, XtWindow(draw_box), draw_box_gc, 0, i * (NROWS/4),
        NROWS, i * (NROWS/4));
  }
}
/*----------------------------------------------------------------------*/
void
inputParams()
{
  int i;
  char c;
  double d;
  char s[32];

  fflush(stdin);

  printf("\nXo = [%lf] ", fXo);
  scanf(" %lf", &fXo);
  fflush(stdin);

  printf("Yo = [%lf] ", fYo);
  scanf(" %lf", &fYo);
  fflush(stdin);

  printf("Xn = [%lf] ", fXn);
  scanf(" %lf", &fXn);
  fflush(stdin);

  printf("Yn = [%lf] ", fYn);
  scanf(" %lf", &fYn);
  fflush(stdin);

  printf("Max Iterations = [%d] ", MAXITER);
  scanf(" %d", &MAXITER);
  fflush(stdin);

  fdX = (fXn - fXo) / (double) NPESMONE;
  fdY = (fYo - fYn) / (double) (NROWS - 1);

  Xo = f2long8((double) fXo);
  Yo = f2long8((double) fYo);
  dX = f2long8((double) fdX);
  dY = f2long8((double) fdY);

  /* debug */
  printf("\n fXo = %lf, Xo = %li", fXo, Xo);
  printf("\n fYo = %lf, Yo = %li", fYo, Yo);
  printf("\n fdX = %lf, dX = %li", fdX, dX);
  printf("\n fdY = %lf, dY = %li\n\n", fdY, dY);

}
/*----------------------------------------------------------------------*/
/* converts a double number to fixed-point integer with 8 bits integer
 * and 24 bit fractional part
 */
long
f2long8(double f)
{
  long  sign;   /* sign of f */
  long  l;      /* converted number */
  int   i;
  long    d;

  if (f < 0)
  {
    sign = -1;
    f = -f;
  }
  else
    sign = +1;

  /* integer part */
  l = ((long) floor(f)) << 24;

  f -= floor(f);
  for (i = 0; i < 24; ++i)
  {
    d = f >= (double) 1.0 / (double) (2 << i) ? 1 : 0;
    l += d << (23 - i);
    f -= (double) d / (double) (2 << i);
  }
  return (l * sign);
}
/************************************************************************/
