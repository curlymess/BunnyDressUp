/************************************************************************
 * File: main.c  Program: microXmandel, same as miniXmandel but 128 x 128
 * pixels and 4 x 4 tiles
 *
 * Contents: main program
 * Andrea Di Blas, april 24, 2002, rev. 2013, rev. 2014
 * Mandelbrot set microscope for Kestrel
 *
 * NOTE: the X resource binding file is in ~/MicroXmandel.x
 ************************************************************************/

#include "gui.h"
#include <X11/Intrinsic.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Command.h>

Widget top_shell;                 /* top shell */
Widget top_form;                  /* top shell's top form */
Widget draw_box;                  /* draw box */
Widget button_box;                /* button box */

XColor rosso, red;                /* color I ask for and color I get */
XColor rosa, pink;                /* color I ask for and color I get */
XColor arancio, orange;           /* color I ask for and color I get */
XColor grigioscuro, darkgrey;     /* color I ask for and color I get */
XColor verde, green;              /* color I ask for and color I get */
XColor blu, blue;                 /* color I ask for and color I get */
XColor giallo, yellow;            /* color I ask for and color I get */
XColor azzurro, cyan;             /* color I ask for and color I get */
XColor grigiochiaro, lightgrey;   /* color I ask for and color I get */

GC draw_box_gc;                   /* graphics context */

Display *display;                 /* display */

XtActionsRec action_table[] =     /* button bindings def in ~/MicroXmandel.x */
{
    "startk",     start_kestrel_cb,
    "startkt",    start_kestrel_tiles_cb,
    "startc",     start_cpu_cb,
    "load",       load_cb,
    "loadp",      loadp_cb,
    "clear",      clear_cb,
    "par",        par_cb,
    "grid",       grid_cb,
    "quit",       quit_cb
};

/************************************************************************/
int
main(int argc, char **argv)
{
  XtAppContext context;

  Widget startk_button;       /* run Kestrel with kMandel.sh */
  Widget startkt_button;      /* run Kestrel with kMandelSPPM.sh */
  Widget startc_button;       /* run on cpu */
  Widget clear_button;        /* clean draw window */
  Widget par_button;          /* prints out parameters */
  Widget grid_button;         /* draw a 4 x 4 grid */
  Widget load_button;         /* load a cpu-generated file or kMandle file */
  Widget loadp_button;        /* load a tile file from kMandelSPPM */
  Widget quit_button;         /* quit */

  /* init user interface */
  top_shell = XtAppInitialize(&context, "MicroXmandel.x", NULL, 0, &argc, argv,
      NULL, NULL, 0);

  /* open display */
  display = XtDisplay(top_shell);

  /* register action procedures */
  XtAppAddActions(context, action_table,
      sizeof(action_table) / sizeof(action_table[0]));

  /* create widget tree */
  top_form = XtCreateManagedWidget("top_form", formWidgetClass, top_shell, NULL,
      0);

  draw_box = XtVaCreateManagedWidget("draw_box", boxWidgetClass, top_form,
      XtNbottom, XawChainBottom, NULL);

  button_box = XtVaCreateManagedWidget("button_box", boxWidgetClass, top_form,
      XtNfromVert, draw_box, XtNleft, XawChainLeft, XtNright, XawChainLeft,
      XtNtop, XawChainBottom, XtNbottom, XawChainBottom, NULL);

  startk_button = XtVaCreateManagedWidget("startk_button", commandWidgetClass,
      button_box, NULL);

  startkt_button = XtVaCreateManagedWidget("startkt_button", commandWidgetClass,
      button_box, NULL);

  startc_button = XtVaCreateManagedWidget("startc_button", commandWidgetClass,
      button_box, NULL);

  load_button = XtVaCreateManagedWidget("load_button", commandWidgetClass,
      button_box, NULL);

  loadp_button = XtVaCreateManagedWidget("loadp_button", commandWidgetClass,
      button_box, NULL);

  clear_button = XtVaCreateManagedWidget("clear_button", commandWidgetClass,
      button_box, NULL);

  par_button = XtVaCreateManagedWidget("par_button", commandWidgetClass,
      button_box, NULL);

  grid_button = XtVaCreateManagedWidget("grid_button", commandWidgetClass,
      button_box, NULL);

  quit_button = XtVaCreateManagedWidget("quit_button", commandWidgetClass,
      button_box, NULL);

  /* realize Widgets */
  XtRealizeWidget(top_shell);

  /* chiedo il colore rosso */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "red", &rosso, &red);

  /* chiedo il colore rosa */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "pink", &rosa, &pink);

  /* chiedo il colore arancio */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "orange", &arancio, &orange);

  /* chiedo il colore grigioscuro */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "darkgrey", &grigioscuro, &darkgrey);

  /* chiedo il colore verde */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "green", &verde, &green);

  /* chiedo il colore blu */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "blue", &blu, &blue);

  /* chiedo il colore giallo */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "yellow", &giallo, &yellow);

  /* chiedo il colore azzurro */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "cyan", &azzurro, &cyan);

  /* chiedo il colore grigiochiaro */
  XAllocNamedColor(display, DefaultColormap(display, 0) ,
  "lightgray", &grigiochiaro, &lightgrey);

  /* create private graphics context */
  draw_box_gc = XCreateGC(display, (Drawable) XtWindowOfObject(draw_box), 0,
      NULL );

  /* event loop */
  XtAppMainLoop(context);

  exit(0);

}
/************************************************************************/
/************************************************************************/
/************************************************************************/

